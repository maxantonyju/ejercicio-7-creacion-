package com.example.laboratorio3practica7

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.laboratorio3practica7.ui.theme.Laboratorio3Practica7Theme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Laboratorio3Practica7Theme {
                AllComponentsExample()
            }
        }
    }
}

// ------------------- Correcciones y Adiciones -------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllComponentsExample() {
    val itemsList = (1..10).map { "Item $it" }
    var textValue by remember { mutableStateOf("") }
    var dialogOpen by remember { mutableStateOf(false) }
    var isChecked by remember { mutableStateOf(false) }
    var switchChecked by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var sliderValue by remember { mutableStateOf(0.5f) }
    var radioSelection by remember { mutableStateOf("Opción 1") }
    val radioOptions = listOf("Opción 1", "Opción 2", "Opción 3")

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Laboratorio de Componentes") })
        },
        bottomBar = {
            NavigationBar {
                itemsList.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = index == 0,
                        onClick = { /* Acción */ },
                        icon = { Icon(painterResource(id = R.drawable.ic_launcher_foreground), contentDescription = null) },
                        label = { Text("Etiqueta") }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                scope.launch { snackbarHostState.showSnackbar("FAB presionado!") }
            }) {
                Icon(painterResource(id = R.drawable.ic_launcher_foreground), contentDescription = null)
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Contenedores
            item {
                Text("Contenedores", style = MaterialTheme.typography.headlineMedium)
            }
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Text("Ejemplo de Card", modifier = Modifier.padding(16.dp))
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().height(50.dp).padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Text("Row Item 1")
                    Text("Row Item 2")
                }
            }
            item {
                Divider()
            }

            // Controles
            item {
                Text("Controles", style = MaterialTheme.typography.headlineMedium)
            }
            item {
                Button(onClick = { dialogOpen = true }) {
                    Text("Mostrar Diálogo")
                }
            }
            item {
                OutlinedTextField(
                    // Parámetro 'value' y 'onValueChange' son obligatorios
                    value = textValue,
                    onValueChange = { newValue -> textValue = newValue },
                    label = { Text("OutlinedTextField") }
                )
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Parámetro 'checked' y 'onCheckedChange' son obligatorios
                    Checkbox(checked = isChecked, onCheckedChange = { newChecked -> isChecked = newChecked })
                    Text("Checkbox")
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Parámetro 'checked' y 'onCheckedChange' son obligatorios
                    Switch(checked = switchChecked, onCheckedChange = { newChecked -> switchChecked = newChecked })
                    Text("Switch")
                }
            }
            item {
                Text("Progreso")
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            item {
                Text("Slider")
                Slider(value = sliderValue, onValueChange = { sliderValue = it }, steps = 4)
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    radioOptions.forEach { text ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = (text == radioSelection), onClick = { radioSelection = text })
                            Text(text = text, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }
            item {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_foreground),
                    contentDescription = "Imagen",
                    modifier = Modifier.size(100.dp).clip(CircleShape)
                )
            }

            // Contenedores Lazy
            item {
                Text("Contenedores Lazy", style = MaterialTheme.typography.headlineMedium)
            }
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(itemsList) { item ->
                        Surface(
                            modifier = Modifier.width(80.dp).fillMaxHeight(),
                            color = Color.LightGray
                        ) {
                            Text(item, modifier = Modifier.padding(16.dp))
                        }
                    }
                }
            }
            item {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxWidth().height(200.dp)
                ) {
                    items(itemsList.size) { index ->
                        Text("Grid ${index + 1}", modifier = Modifier.padding(8.dp))
                    }
                }
            }
        }
    }

    if (dialogOpen) {
        AlertDialog(
            onDismissRequest = { dialogOpen = false },
            title = { Text("Diálogo de Alerta") },
            text = { Text("Esto es un ejemplo de un AlertDialog.") },
            confirmButton = {
                Button(onClick = { dialogOpen = false }) { Text("Aceptar") }
            }
        )
    }
}

@Preview(showBackground = true, name = "Todos los Componentes")
@Composable
fun AllComponentsPreview() {
    Laboratorio3Practica7Theme {
        AllComponentsExample()
    }
}